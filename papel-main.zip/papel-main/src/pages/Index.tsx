import { useState } from 'react';
import { Header } from '@/components/factory/Header';
import { Navigation } from '@/components/factory/Navigation';
import { InicioTurno } from '@/components/factory/sections/InicioTurno';
import { Relevo } from '@/components/factory/sections/Relevo';
import { ParteMaquina } from '@/components/factory/sections/ParteMaquina';
import { Productos } from '@/components/factory/sections/Productos';
import { Produccion } from '@/components/factory/sections/Produccion';
import { CuchillasLavados } from '@/components/factory/sections/CuchillasLavados';
import { RoturasParadas } from '@/components/factory/sections/RoturasParadas';
import { Recetas } from '@/components/factory/sections/Recetas';
import { Rebobinadora } from '@/components/factory/sections/Rebobinadora';
import { CambiosPapel } from '@/components/factory/sections/CambiosPapel';
import { Resumen } from '@/components/factory/sections/Resumen';
import { HistorialProducciones } from '@/components/factory/sections/HistorialProducciones';
import { useLocalStorage } from '@/hooks/useLocalStorage';
import { 
  TurnoInfo, 
  Relevo as RelevoType,
  AccionMaquina,
  Producto,
  Bobina,
  KilosCortados,
  CambioCuchilla,
  Lavado,
  Rotura,
  Parada,
  Receta,
  CorteRebobinadora,
  CambioPapel
} from '@/types/factory';

const Index = () => {
  const [activeSection, setActiveSection] = useState('inicio');
  const [turnoInfo, setTurnoInfo] = useLocalStorage<TurnoInfo | null>('factory-turno', null);
  const [relevo, setRelevo] = useLocalStorage<RelevoType | null>('factory-relevo', null);
  const [acciones, setAcciones] = useLocalStorage<AccionMaquina[]>('factory-acciones', []);
  const [productos, setProductos] = useLocalStorage<Producto[]>('factory-productos', []);
  const [bobinas, setBobinas] = useLocalStorage<Bobina[]>('factory-bobinas', []);
  const [kilosCortados, setKilosCortados] = useLocalStorage<KilosCortados[]>('factory-kilos-cortados', []);
  const [cuchillas, setCuchillas] = useLocalStorage<CambioCuchilla[]>('factory-cuchillas', []);
  const [lavados, setLavados] = useLocalStorage<Lavado[]>('factory-lavados', []);
  const [roturas, setRoturas] = useLocalStorage<Rotura[]>('factory-roturas', []);
  const [paradas, setParadas] = useLocalStorage<Parada[]>('factory-paradas', []);
  const [recetas, setRecetas] = useLocalStorage<Receta[]>('factory-recetas', []);
  const [cortesRebobinadora, setCortesRebobinadora] = useLocalStorage<CorteRebobinadora[]>('factory-cortes-rebobinadora', []);
  const [cambiosPapel, setCambiosPapel] = useLocalStorage<CambioPapel[]>('factory-cambios-papel', []);

  const turnoActivo = turnoInfo?.activo === true;

  const handleLimpiarTodo = () => {
    setTurnoInfo(null);
    setRelevo(null);
    setAcciones([]);
    setProductos([]);
    setBobinas([]);
    setKilosCortados([]);
    setCuchillas([]);
    setLavados([]);
    setRoturas([]);
    setParadas([]);
    setRecetas([]);
    setCortesRebobinadora([]);
    setCambiosPapel([]);
    setActiveSection('inicio');
  };

  const renderSection = () => {
    switch (activeSection) {
      case 'inicio':
        return (
          <InicioTurno 
            turnoInfo={turnoInfo} 
            onTurnoChange={(data) => {
              setTurnoInfo(data);
              if (data.activo) {
                setActiveSection('maquina');
              }
            }} 
          />
        );
      case 'relevo':
        return <Relevo relevo={relevo} onRelevoChange={setRelevo} />;
      case 'maquina':
        return <ParteMaquina acciones={acciones} onAccionesChange={setAcciones} />;
      case 'productos':
        return <Productos productos={productos} onProductosChange={setProductos} />;
      case 'produccion':
        return (
          <Produccion 
            bobinas={bobinas} 
            onBobinasChange={setBobinas}
            kilosCortados={kilosCortados}
            onKilosCortadosChange={setKilosCortados}
          />
        );
      case 'cuchillas':
        return (
          <CuchillasLavados 
            cuchillas={cuchillas}
            onCuchillasChange={setCuchillas}
            lavados={lavados}
            onLavadosChange={setLavados}
          />
        );
      case 'paradas':
        return (
          <RoturasParadas 
            roturas={roturas}
            onRoturasChange={setRoturas}
            paradas={paradas}
            onParadasChange={setParadas}
          />
        );
      case 'recetas':
        return <Recetas recetas={recetas} onRecetasChange={setRecetas} />;
      case 'rebobinadora':
        return <Rebobinadora cortes={cortesRebobinadora} onCortesChange={setCortesRebobinadora} />;
      case 'cambios':
        return <CambiosPapel cambios={cambiosPapel} onCambiosChange={setCambiosPapel} />;
      case 'historial':
        return <HistorialProducciones />;
      case 'resumen':
        return (
          <Resumen 
            turnoInfo={turnoInfo}
            relevo={relevo}
            acciones={acciones}
            productos={productos}
            bobinas={bobinas}
            kilosCortados={kilosCortados}
            cuchillas={cuchillas}
            lavados={lavados}
            roturas={roturas}
            paradas={paradas}
            recetas={recetas}
            cortes={cortesRebobinadora}
            cambios={cambiosPapel}
            onLimpiarTodo={handleLimpiarTodo}
          />
        );
      default:
        return <InicioTurno turnoInfo={turnoInfo} onTurnoChange={setTurnoInfo} />;
    }
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Header turnoInfo={turnoInfo} />
      
      <div className="flex flex-1">
        <Navigation 
          activeSection={activeSection} 
          onSectionChange={setActiveSection}
          turnoActivo={turnoActivo}
        />
        
        <main className="flex-1 p-4 md:p-6 overflow-auto lg:ml-0">
          {renderSection()}
        </main>
      </div>
    </div>
  );
};

export default Index;
