export interface TurnoInfo {
  fecha: string;
  turno: string;
  maquinista: string;
  ayudante: string;
  maquina: string;
  activo: boolean;
}

export interface Relevo {
  informacion: string;
  problemasPendientes: string;
  estadoMaquina: string;
  fechaGuardado: string;
}

export interface AccionMaquina {
  id: string;
  hora: string;
  tipoAccion: string;
  velocidad: number;
  comentario: string;
}

export interface Producto {
  id: string;
  tipo: string;
  codigo: string;
  gramaje: number;
  crepado: string;
  ancho: number;
  cliente: string;
  horaInicio: string;
  horaFin: string;
}

export interface Bobina {
  id: string;
  numero: number;
  peso: number;
  tipo: 'Buena' | 'B' | 'Cortada/Desecho';
}

export interface KilosCortados {
  id: string;
  motivo: string;
  kilos: number;
}

export interface CambioCuchilla {
  id: string;
  fechaHora: string;
  tipo: 'Crepado' | 'Limpieza';
  motivo: string;
  motivoOtro: string;
  observaciones: string;
}

export interface Lavado {
  id: string;
  fechaHora: string;
  tipo: string;
  parteLavada: string;
  motivo: string;
  tiempo: number;
}

export interface Rotura {
  id: string;
  horaInicio: string;
  horaFin: string;
  duracion: number;
  motivo: string;
  producto: string;
}

export interface Parada {
  id: string;
  horaInicio: string;
  horaFin: string;
  duracion: number;
  tipo: string;
  motivoDetallado: string;
}

export interface Receta {
  id: string;
  nombre: string;
  producto: string;
  comentario: string;
  noRepetir: boolean;
}

export interface CorteRebobinadora {
  id: string;
  fechaHora: string;
  bobina: string;
  pesoInicial: number;
  pesoFinal: number;
  anchoCorte: number;
  observaciones: string;
}

export interface CambioPapel {
  id: string;
  fechaHora: string;
  productoAnterior: string;
  productoNuevo: string;
  velocidadAntes: number;
  velocidadDespues: number;
  tensionAntes: number;
  tensionDespues: number;
  crepado: string;
  observaciones: string;
}
