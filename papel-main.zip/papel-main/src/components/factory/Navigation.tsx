import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { 
  Play, 
  MessageSquare, 
  Gauge, 
  Package, 
  Scale, 
  Wrench, 
  AlertTriangle, 
  BookOpen, 
  RotateCcw, 
  FileText, 
  Download,
  Menu,
  X
} from 'lucide-react';
import { useState } from 'react';

interface NavigationProps {
  activeSection: string;
  onSectionChange: (section: string) => void;
  turnoActivo: boolean;
}

const sections = [
  { id: 'inicio', label: 'Inicio de Turno', icon: Play, requiresTurno: false },
  { id: 'relevo', label: 'Relevo', icon: MessageSquare, requiresTurno: true },
  { id: 'maquina', label: 'Parte de Máquina', icon: Gauge, requiresTurno: true },
  { id: 'productos', label: 'Pedidos y Productos', icon: Package, requiresTurno: true },
  { id: 'produccion', label: 'Producción y Kilos', icon: Scale, requiresTurno: true },
  { id: 'cuchillas', label: 'Lavados', icon: Wrench, requiresTurno: true },
  { id: 'paradas', label: 'Roturas y Paradas', icon: AlertTriangle, requiresTurno: true },
  { id: 'recetas', label: 'Recetas', icon: BookOpen, requiresTurno: true },
  { id: 'rebobinadora', label: 'Rebobinadora', icon: RotateCcw, requiresTurno: true },
  { id: 'cambios', label: 'Cambios de Papel', icon: FileText, requiresTurno: true },
  { id: 'historial', label: 'Historial Producciones', icon: BookOpen, requiresTurno: true },
  { id: 'resumen', label: 'Resumen / Exportar', icon: Download, requiresTurno: true },
];

export function Navigation({ activeSection, onSectionChange, turnoActivo }: NavigationProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <>
      {/* Mobile menu button */}
      <Button
        variant="outline"
        size="icon"
        className="fixed top-4 left-4 z-50 lg:hidden no-print"
        onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
      >
        {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
      </Button>

      {/* Overlay for mobile */}
      {mobileMenuOpen && (
        <div 
          className="fixed inset-0 bg-foreground/50 z-40 lg:hidden"
          onClick={() => setMobileMenuOpen(false)}
        />
      )}

      {/* Navigation sidebar */}
      <nav className={cn(
        "fixed left-0 top-0 h-full w-72 bg-card border-r border-border z-40 transition-transform duration-300 overflow-y-auto no-print",
        "lg:translate-x-0 lg:static lg:h-auto lg:min-h-screen",
        mobileMenuOpen ? "translate-x-0" : "-translate-x-full"
      )}>
        <div className="p-4 pt-16 lg:pt-4">
          <h2 className="text-lg font-semibold text-foreground mb-4 px-2">Secciones</h2>
          <div className="space-y-2">
            {sections.map((section) => {
              const Icon = section.icon;
              const disabled = section.requiresTurno && !turnoActivo;
              
              return (
                <Button
                  key={section.id}
                  variant={activeSection === section.id ? "default" : "ghost"}
                  className={cn(
                    "w-full justify-start text-left h-auto py-3 px-4",
                    disabled && "opacity-50 cursor-not-allowed"
                  )}
                  disabled={disabled}
                  onClick={() => {
                    onSectionChange(section.id);
                    setMobileMenuOpen(false);
                  }}
                >
                  <Icon className="w-5 h-5 mr-3 flex-shrink-0" />
                  <span className="text-sm font-medium">{section.label}</span>
                </Button>
              );
            })}
          </div>
        </div>
      </nav>
    </>
  );
}
