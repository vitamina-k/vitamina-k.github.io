import { TurnoInfo } from '@/types/factory';
import { Badge } from '@/components/ui/badge';
import { Calendar, User, Settings, Clock } from 'lucide-react';

interface HeaderProps {
  turnoInfo: TurnoInfo | null;
}

export function Header({ turnoInfo }: HeaderProps) {
  if (!turnoInfo?.activo) {
    return (
      <header className="bg-primary text-primary-foreground p-4 shadow-lg">
        <h1 className="text-2xl font-bold text-center">📋 Libreta de Fábrica de Papel</h1>
        <p className="text-center text-primary-foreground/80 mt-1">Inicie un turno para comenzar</p>
      </header>
    );
  }

  return (
    <header className="bg-primary text-primary-foreground p-4 shadow-lg">
      <h1 className="text-xl font-bold text-center mb-3">📋 Libreta de Fábrica de Papel</h1>
      <div className="flex flex-wrap justify-center gap-3">
        <Badge variant="secondary" className="text-base px-4 py-2 flex items-center gap-2">
          <Clock className="w-4 h-4" />
          {turnoInfo.turno}
        </Badge>
        <Badge variant="secondary" className="text-base px-4 py-2 flex items-center gap-2">
          <Calendar className="w-4 h-4" />
          {turnoInfo.fecha}
        </Badge>
        <Badge variant="secondary" className="text-base px-4 py-2 flex items-center gap-2">
          <User className="w-4 h-4" />
          {turnoInfo.maquinista}
        </Badge>
        <Badge variant="secondary" className="text-base px-4 py-2 flex items-center gap-2">
          <Settings className="w-4 h-4" />
          {turnoInfo.maquina}
        </Badge>
      </div>
    </header>
  );
}
