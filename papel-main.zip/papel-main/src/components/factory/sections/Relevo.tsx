import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Relevo as RelevoType } from '@/types/factory';
import { MessageSquare, Save } from 'lucide-react';
import { toast } from 'sonner';

interface RelevoProps {
  relevo: RelevoType | null;
  onRelevoChange: (relevo: RelevoType) => void;
}

export function Relevo({ relevo, onRelevoChange }: RelevoProps) {
  const [informacion, setInformacion] = useState('');
  const [problemasPendientes, setProblemasPendientes] = useState('');
  const [estadoMaquina, setEstadoMaquina] = useState('');

  useEffect(() => {
    if (relevo) {
      setInformacion(relevo.informacion);
      setProblemasPendientes(relevo.problemasPendientes);
      setEstadoMaquina(relevo.estadoMaquina);
    }
  }, [relevo]);

  const handleGuardar = () => {
    onRelevoChange({
      informacion,
      problemasPendientes,
      estadoMaquina,
      fechaGuardado: new Date().toISOString(),
    });
    toast.success('Relevo guardado correctamente');
  };

  return (
    <Card className="max-w-3xl mx-auto">
      <CardHeader>
        <CardTitle className="text-2xl flex items-center gap-3">
          <MessageSquare className="w-7 h-7 text-primary" />
          Información de Relevo
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-2">
          <Label className="text-base font-medium">Información para el siguiente turno</Label>
          <Textarea
            value={informacion}
            onChange={(e) => setInformacion(e.target.value)}
            placeholder="Escriba aquí la información importante para el siguiente turno..."
            className="min-h-[150px] text-base"
          />
        </div>

        <div className="space-y-2">
          <Label className="text-base font-medium">Problemas pendientes</Label>
          <Textarea
            value={problemasPendientes}
            onChange={(e) => setProblemasPendientes(e.target.value)}
            placeholder="Describa los problemas que quedan pendientes..."
            className="min-h-[120px] text-base"
          />
        </div>

        <div className="space-y-2">
          <Label className="text-base font-medium">Estado de la máquina</Label>
          <Textarea
            value={estadoMaquina}
            onChange={(e) => setEstadoMaquina(e.target.value)}
            placeholder="Describa el estado actual de la máquina..."
            className="min-h-[120px] text-base"
          />
        </div>

        <Button 
          onClick={handleGuardar} 
          size="lg" 
          className="w-full h-14 text-lg font-semibold"
        >
          <Save className="w-5 h-5 mr-2" />
          Guardar Relevo
        </Button>

        {relevo?.fechaGuardado && (
          <p className="text-sm text-muted-foreground text-center">
            Último guardado: {new Date(relevo.fechaGuardado).toLocaleString('es-ES')}
          </p>
        )}
      </CardContent>
    </Card>
  );
}
