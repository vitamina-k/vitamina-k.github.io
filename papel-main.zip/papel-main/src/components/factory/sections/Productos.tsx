import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Producto } from '@/types/factory';
import { Package, Plus, Trash2 } from 'lucide-react';
import { toast } from 'sonner';

interface ProductosProps {
  productos: Producto[];
  onProductosChange: (productos: Producto[]) => void;
}

const tiposProducto = ['Cocina', 'Servilleta', 'Higiénico'];

export function Productos({ productos, onProductosChange }: ProductosProps) {
  const [tipo, setTipo] = useState('');
  const [codigo, setCodigo] = useState('');
  const [gramaje, setGramaje] = useState('');
  const [crepado, setCrepado] = useState('');
  const [ancho, setAncho] = useState('');
  const [cliente, setCliente] = useState('');
  const [horaInicio, setHoraInicio] = useState('');

  const handleAnadir = () => {
    if (!tipo || !codigo) {
      toast.error('Complete al menos el tipo y código del producto');
      return;
    }

    const nuevoProducto: Producto = {
      id: Date.now().toString(),
      tipo,
      codigo,
      gramaje: parseFloat(gramaje) || 0,
      crepado,
      ancho: parseFloat(ancho) || 0,
      cliente,
      horaInicio,
      horaFin: '',
    };

    onProductosChange([...productos, nuevoProducto]);
    
    // Reset form
    setTipo('');
    setCodigo('');
    setGramaje('');
    setCrepado('');
    setAncho('');
    setCliente('');
    setHoraInicio('');
    
    toast.success('Producto añadido');
  };

  const handleEliminar = (id: string) => {
    onProductosChange(productos.filter(p => p.id !== id));
    toast.info('Producto eliminado');
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl flex items-center gap-3">
            <Package className="w-7 h-7 text-primary" />
            Pedidos y Productos del Turno
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label className="text-base font-medium">Tipo de producto *</Label>
              <Select value={tipo} onValueChange={setTipo}>
                <SelectTrigger className="text-lg h-12">
                  <SelectValue placeholder="Seleccione tipo" />
                </SelectTrigger>
                <SelectContent>
                  {tiposProducto.map((t) => (
                    <SelectItem key={t} value={t} className="text-base py-3">{t}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2 md:col-span-2">
              <Label className="text-base font-medium">Código completo *</Label>
              <Input
                value={codigo}
                onChange={(e) => setCodigo(e.target.value)}
                placeholder="Ej: WS 19 P16 274C12"
                className="text-lg h-12"
              />
            </div>

            <div className="space-y-2">
              <Label className="text-base font-medium">Gramaje (g/m²)</Label>
              <Input
                type="number"
                value={gramaje}
                onChange={(e) => setGramaje(e.target.value)}
                placeholder="Ej: 19"
                className="text-lg h-12"
              />
            </div>

            <div className="space-y-2">
              <Label className="text-base font-medium">Crepado (%)</Label>
              <Input
                value={crepado}
                onChange={(e) => setCrepado(e.target.value)}
                placeholder="Ej: 16%"
                className="text-lg h-12"
              />
            </div>

            <div className="space-y-2">
              <Label className="text-base font-medium">Ancho (cm)</Label>
              <Input
                type="number"
                value={ancho}
                onChange={(e) => setAncho(e.target.value)}
                placeholder="Ej: 274"
                className="text-lg h-12"
              />
            </div>

            <div className="space-y-2">
              <Label className="text-base font-medium">Cliente</Label>
              <Input
                value={cliente}
                onChange={(e) => setCliente(e.target.value)}
                placeholder="Nombre del cliente"
                className="text-lg h-12"
              />
            </div>

            <div className="space-y-2">
              <Label className="text-base font-medium">Hora inicio</Label>
              <Input
                type="time"
                value={horaInicio}
                onChange={(e) => setHoraInicio(e.target.value)}
                className="text-lg h-12"
              />
            </div>
          </div>

          <Button 
            onClick={handleAnadir} 
            size="lg" 
            className="w-full h-14 text-lg font-semibold"
          >
            <Plus className="w-5 h-5 mr-2" />
            Añadir Producto
          </Button>
        </CardContent>
      </Card>

      {productos.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-xl">Productos del Turno</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Tipo</TableHead>
                    <TableHead>Código</TableHead>
                    <TableHead>Gramaje</TableHead>
                    <TableHead>Crepado</TableHead>
                    <TableHead>Ancho</TableHead>
                    <TableHead>Cliente</TableHead>
                    <TableHead>Hora inicio</TableHead>
                    <TableHead className="w-16"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {productos.map((producto) => (
                    <TableRow key={producto.id}>
                      <TableCell className="font-medium">{producto.tipo}</TableCell>
                      <TableCell className="font-mono">{producto.codigo}</TableCell>
                      <TableCell>{producto.gramaje || '-'}</TableCell>
                      <TableCell>{producto.crepado || '-'}</TableCell>
                      <TableCell>{producto.ancho ? `${producto.ancho} cm` : '-'}</TableCell>
                      <TableCell>{producto.cliente || '-'}</TableCell>
                      <TableCell>{producto.horaInicio || '-'}</TableCell>
                      <TableCell>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleEliminar(producto.id)}
                          className="text-destructive hover:text-destructive"
                        >
                          <Trash2 className="w-5 h-5" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
