import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { 
  TurnoInfo, 
  Relevo as RelevoType, 
  AccionMaquina, 
  Producto, 
  Bobina, 
  KilosCortados,
  CambioCuchilla,
  Lavado,
  Rotura,
  Parada,
  Receta,
  CorteRebobinadora,
  CambioPapel
} from '@/types/factory';
import { Download, FileText, Trash2 } from 'lucide-react';
import { toast } from 'sonner';

interface ResumenProps {
  turnoInfo: TurnoInfo | null;
  relevo: RelevoType | null;
  acciones: AccionMaquina[];
  productos: Producto[];
  bobinas: Bobina[];
  kilosCortados: KilosCortados[];
  cuchillas: CambioCuchilla[];
  lavados: Lavado[];
  roturas: Rotura[];
  paradas: Parada[];
  recetas: Receta[];
  cortes: CorteRebobinadora[];
  cambios: CambioPapel[];
  onLimpiarTodo: () => void;
}

export function Resumen({
  turnoInfo,
  relevo,
  acciones,
  productos,
  bobinas,
  kilosCortados,
  cuchillas,
  lavados,
  roturas,
  paradas,
  recetas,
  cortes,
  cambios,
  onLimpiarTodo,
}: ResumenProps) {
  
  // Cálculos
  const totalBuenos = bobinas.filter(b => b.tipo === 'Buena').reduce((sum, b) => sum + b.peso, 0);
  const totalB = bobinas.filter(b => b.tipo === 'B').reduce((sum, b) => sum + b.peso, 0);
  const totalDesecho = bobinas.filter(b => b.tipo === 'Cortada/Desecho').reduce((sum, b) => sum + b.peso, 0);
  const totalKilosCortados = kilosCortados.reduce((sum, k) => sum + k.kilos, 0);
  const totalMinutosParada = paradas.reduce((sum, p) => sum + p.duracion, 0);
  const totalMinutosRotura = roturas.reduce((sum, r) => sum + r.duracion, 0);

  const generarTexto = () => {
    let texto = `LIBRETA DE FÁBRICA DE PAPEL\n`;
    texto += `${'='.repeat(50)}\n\n`;

    if (turnoInfo) {
      texto += `TURNO: ${turnoInfo.turno}\n`;
      texto += `FECHA: ${turnoInfo.fecha}\n`;
      texto += `MAQUINISTA: ${turnoInfo.maquinista}\n`;
      texto += `AYUDANTE: ${turnoInfo.ayudante || '-'}\n`;
      texto += `MÁQUINA: ${turnoInfo.maquina}\n\n`;
    }

    if (relevo) {
      texto += `${'─'.repeat(50)}\n`;
      texto += `RELEVO\n`;
      texto += `${'─'.repeat(50)}\n`;
      texto += `Información: ${relevo.informacion || '-'}\n`;
      texto += `Problemas pendientes: ${relevo.problemasPendientes || '-'}\n`;
      texto += `Estado máquina: ${relevo.estadoMaquina || '-'}\n\n`;
    }

    if (acciones.length > 0) {
      texto += `${'─'.repeat(50)}\n`;
      texto += `PARTE DE MÁQUINA (${acciones.length} acciones)\n`;
      texto += `${'─'.repeat(50)}\n`;
      acciones.forEach(a => {
        texto += `${a.hora} - ${a.tipoAccion} - Vel: ${a.velocidad || '-'} - ${a.comentario || ''}\n`;
      });
      texto += '\n';
    }

    if (productos.length > 0) {
      texto += `${'─'.repeat(50)}\n`;
      texto += `PRODUCTOS (${productos.length})\n`;
      texto += `${'─'.repeat(50)}\n`;
      productos.forEach(p => {
        texto += `${p.codigo} - ${p.tipo} - Gramaje: ${p.gramaje || '-'} - Ancho: ${p.ancho || '-'}\n`;
      });
      texto += '\n';
    }

    texto += `${'─'.repeat(50)}\n`;
    texto += `PRODUCCIÓN\n`;
    texto += `${'─'.repeat(50)}\n`;
    texto += `Bobinas registradas: ${bobinas.length}\n`;
    texto += `Total kilos buenos: ${totalBuenos.toFixed(0)} kg\n`;
    texto += `Total kilos B: ${totalB.toFixed(0)} kg\n`;
    texto += `Total desecho: ${(totalDesecho + totalKilosCortados).toFixed(0)} kg\n\n`;

    texto += `${'─'.repeat(50)}\n`;
    texto += `INCIDENCIAS\n`;
    texto += `${'─'.repeat(50)}\n`;
    texto += `Cambios de cuchilla: ${cuchillas.length}\n`;
    texto += `Lavados: ${lavados.length}\n`;
    texto += `Roturas: ${roturas.length} (${totalMinutosRotura} min)\n`;
    texto += `Paradas: ${paradas.length} (${totalMinutosParada} min)\n\n`;

    if (recetas.length > 0) {
      texto += `${'─'.repeat(50)}\n`;
      texto += `RECETAS (${recetas.length})\n`;
      texto += `${'─'.repeat(50)}\n`;
      recetas.forEach(r => {
        texto += `${r.nombre} - ${r.producto}${r.noRepetir ? ' [NO REPETIR]' : ''}\n`;
      });
      texto += '\n';
    }

    if (cambios.length > 0) {
      texto += `${'─'.repeat(50)}\n`;
      texto += `CAMBIOS DE PAPEL (${cambios.length})\n`;
      texto += `${'─'.repeat(50)}\n`;
      cambios.forEach(c => {
        texto += `${c.productoAnterior} → ${c.productoNuevo}\n`;
      });
    }

    return texto;
  };

  const handleExportarTexto = () => {
    const texto = generarTexto();
    const blob = new Blob([texto], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `turno_${turnoInfo?.fecha || 'sin-fecha'}_${turnoInfo?.turno || 'sin-turno'}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    toast.success('Archivo exportado');
  };

  const handleExportarJSON = () => {
    const data = {
      turnoInfo,
      relevo,
      acciones,
      productos,
      bobinas,
      kilosCortados,
      cuchillas,
      lavados,
      roturas,
      paradas,
      recetas,
      cortes,
      cambios,
      exportadoEn: new Date().toISOString(),
    };
    
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `turno_${turnoInfo?.fecha || 'sin-fecha'}_${turnoInfo?.turno || 'sin-turno'}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    toast.success('Archivo JSON exportado');
  };

  const handleImprimir = () => {
    window.print();
  };

  const handleLimpiar = () => {
    if (confirm('¿Está seguro de que desea limpiar todos los datos del turno? Esta acción no se puede deshacer.')) {
      onLimpiarTodo();
      toast.success('Datos limpiados');
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl flex items-center gap-3">
            <FileText className="w-7 h-7 text-primary" />
            Resumen del Turno
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Info del turno */}
          {turnoInfo && (
            <div className="bg-primary/10 p-4 rounded-lg">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                <div>
                  <p className="text-sm text-muted-foreground">Fecha</p>
                  <p className="font-semibold text-lg">{turnoInfo.fecha}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Turno</p>
                  <p className="font-semibold text-lg">{turnoInfo.turno}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Maquinista</p>
                  <p className="font-semibold text-lg">{turnoInfo.maquinista}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Máquina</p>
                  <p className="font-semibold text-lg">{turnoInfo.maquina}</p>
                </div>
              </div>
            </div>
          )}

          <Separator />

          {/* Estadísticas rápidas */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Card>
              <CardContent className="p-4 text-center">
                <p className="text-3xl font-bold text-accent">{totalBuenos.toFixed(0)}</p>
                <p className="text-sm text-muted-foreground">kg Buenos</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4 text-center">
                <p className="text-3xl font-bold text-destructive">{(totalDesecho + totalKilosCortados).toFixed(0)}</p>
                <p className="text-sm text-muted-foreground">kg Merma</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4 text-center">
                <p className="text-3xl font-bold text-primary">{productos.length}</p>
                <p className="text-sm text-muted-foreground">Productos</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4 text-center">
                <p className="text-3xl font-bold" style={{ color: 'hsl(var(--warning))' }}>{totalMinutosParada + totalMinutosRotura}</p>
                <p className="text-sm text-muted-foreground">min Paradas</p>
              </CardContent>
            </Card>
          </div>

          <Separator />

          {/* Contadores */}
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4 text-center">
            <div className="p-3 bg-muted rounded-lg">
              <p className="text-2xl font-bold">{acciones.length}</p>
              <p className="text-xs text-muted-foreground">Acciones</p>
            </div>
            <div className="p-3 bg-muted rounded-lg">
              <p className="text-2xl font-bold">{bobinas.length}</p>
              <p className="text-xs text-muted-foreground">Bobinas</p>
            </div>
            <div className="p-3 bg-muted rounded-lg">
              <p className="text-2xl font-bold">{cuchillas.length}</p>
              <p className="text-xs text-muted-foreground">Cuchillas</p>
            </div>
            <div className="p-3 bg-muted rounded-lg">
              <p className="text-2xl font-bold">{lavados.length}</p>
              <p className="text-xs text-muted-foreground">Lavados</p>
            </div>
            <div className="p-3 bg-muted rounded-lg">
              <p className="text-2xl font-bold">{cambios.length}</p>
              <p className="text-xs text-muted-foreground">Cambios</p>
            </div>
          </div>

          <Separator />

          {/* Botones de exportación */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Button onClick={handleExportarTexto} size="lg" className="h-14 text-lg">
              <Download className="w-5 h-5 mr-2" />
              Exportar TXT
            </Button>
            <Button onClick={handleExportarJSON} size="lg" variant="secondary" className="h-14 text-lg">
              <Download className="w-5 h-5 mr-2" />
              Exportar JSON
            </Button>
            <Button onClick={handleImprimir} size="lg" variant="outline" className="h-14 text-lg">
              <FileText className="w-5 h-5 mr-2" />
              Imprimir
            </Button>
          </div>

          <Separator />

          <Button 
            onClick={handleLimpiar} 
            size="lg" 
            variant="destructive" 
            className="w-full h-14 text-lg"
          >
            <Trash2 className="w-5 h-5 mr-2" />
            Limpiar Todos los Datos
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
