import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Rotura, Parada } from '@/types/factory';
import { AlertTriangle, Clock, Plus, Trash2, Zap } from 'lucide-react';
import { toast } from 'sonner';
import { useLocalStorage } from '@/hooks/useLocalStorage';

interface RoturasParadasProps {
  roturas: Rotura[];
  paradas: Parada[];
  onRoturasChange: (roturas: Rotura[]) => void;
  onParadasChange: (paradas: Parada[]) => void;
}

const tiposParadaDefault = ['Programada', 'Avería mecánica', 'Avería eléctrica', 'Falta de pasta', 'Cambio de producto'];

export function RoturasParadas({ roturas, paradas, onRoturasChange, onParadasChange }: RoturasParadasProps) {
  const [motivosPersonalizados, setMotivosPersonalizados] = useLocalStorage<string[]>('factory_motivos_parada', []);
  
  // Roturas state
  const [horaInicioRotura, setHoraInicioRotura] = useState('');
  const [horaFinRotura, setHoraFinRotura] = useState('');
  const [motivoRotura, setMotivoRotura] = useState('');

  // Paradas state
  const [horaInicioParada, setHoraInicioParada] = useState('');
  const [horaFinParada, setHoraFinParada] = useState('');
  const [tipoParada, setTipoParada] = useState('');
  const [motivoParada, setMotivoParada] = useState('');
  const [nuevoMotivo, setNuevoMotivo] = useState('');

  const tiposParada = [...tiposParadaDefault, ...motivosPersonalizados, 'Otro'];

  const calcularDuracion = (inicio: string, fin: string): number => {
    if (!inicio || !fin) return 0;
    const [h1, m1] = inicio.split(':').map(Number);
    const [h2, m2] = fin.split(':').map(Number);
    let minutos = (h2 * 60 + m2) - (h1 * 60 + m1);
    if (minutos < 0) minutos += 24 * 60; // Cruce de medianoche
    return minutos;
  };

  const handleHoraActualRoturaInicio = () => {
    setHoraInicioRotura(new Date().toTimeString().slice(0, 5));
  };

  const handleHoraActualRoturaFin = () => {
    setHoraFinRotura(new Date().toTimeString().slice(0, 5));
  };

  const handleHoraActualParadaInicio = () => {
    setHoraInicioParada(new Date().toTimeString().slice(0, 5));
  };

  const handleHoraActualParadaFin = () => {
    setHoraFinParada(new Date().toTimeString().slice(0, 5));
  };

  const handleAnadirRotura = () => {
    if (!horaInicioRotura || !motivoRotura) {
      toast.error('Complete al menos la hora de inicio y el motivo');
      return;
    }

    const nuevaRotura: Rotura = {
      id: Date.now().toString(),
      horaInicio: horaInicioRotura,
      horaFin: horaFinRotura,
      duracion: calcularDuracion(horaInicioRotura, horaFinRotura),
      motivo: motivoRotura,
      producto: '',
    };

    onRoturasChange([...roturas, nuevaRotura]);
    setHoraInicioRotura('');
    setHoraFinRotura('');
    setMotivoRotura('');
    toast.success('Rotura registrada');
  };

  const handleAnadirParada = () => {
    if (!horaInicioParada || !tipoParada) {
      toast.error('Complete al menos la hora de inicio y el tipo');
      return;
    }

    // Si es "Otro" y hay un nuevo motivo, guardarlo
    if (tipoParada === 'Otro' && nuevoMotivo.trim()) {
      setMotivosPersonalizados([...motivosPersonalizados, nuevoMotivo.trim()]);
    }

    const nuevaParada: Parada = {
      id: Date.now().toString(),
      horaInicio: horaInicioParada,
      horaFin: horaFinParada,
      duracion: calcularDuracion(horaInicioParada, horaFinParada),
      tipo: tipoParada === 'Otro' && nuevoMotivo.trim() ? nuevoMotivo.trim() : tipoParada,
      motivoDetallado: motivoParada,
    };

    onParadasChange([...paradas, nuevaParada]);
    setHoraInicioParada('');
    setHoraFinParada('');
    setTipoParada('');
    setMotivoParada('');
    setNuevoMotivo('');
    toast.success('Parada registrada');
  };

  const totalMinutosParada = paradas.reduce((sum, p) => sum + p.duracion, 0);
  const totalMinutosRotura = roturas.reduce((sum, r) => sum + r.duracion, 0);

  return (
    <div className="space-y-6">
      {/* Resumen */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card className="bg-destructive/10">
          <CardContent className="p-4 text-center">
            <p className="text-sm text-muted-foreground">Total Roturas</p>
            <p className="text-2xl font-bold text-destructive">
              {roturas.length} ({totalMinutosRotura} min)
            </p>
          </CardContent>
        </Card>
        <Card className="bg-warning/10">
          <CardContent className="p-4 text-center">
            <p className="text-sm text-muted-foreground">Total Paradas</p>
            <p className="text-2xl font-bold" style={{ color: 'hsl(var(--warning))' }}>
              {paradas.length} ({totalMinutosParada} min)
            </p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="roturas" className="space-y-6">
        <TabsList className="grid w-full grid-cols-2 h-14">
          <TabsTrigger value="roturas" className="text-base h-12">
            <Zap className="w-5 h-5 mr-2" />
            Roturas
          </TabsTrigger>
          <TabsTrigger value="paradas" className="text-base h-12">
            <AlertTriangle className="w-5 h-5 mr-2" />
            Paradas
          </TabsTrigger>
        </TabsList>

        <TabsContent value="roturas" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl flex items-center gap-3">
                <Zap className="w-7 h-7 text-destructive" />
                Roturas
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label className="text-base font-medium">Hora inicio *</Label>
                  <div className="flex gap-2">
                    <Input
                      type="time"
                      value={horaInicioRotura}
                      onChange={(e) => setHoraInicioRotura(e.target.value)}
                      className="text-lg h-12 flex-1"
                    />
                    <Button variant="outline" onClick={handleHoraActualRoturaInicio} className="h-12">
                      <Clock className="w-5 h-5" />
                    </Button>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label className="text-base font-medium">Hora fin</Label>
                  <div className="flex gap-2">
                    <Input
                      type="time"
                      value={horaFinRotura}
                      onChange={(e) => setHoraFinRotura(e.target.value)}
                      className="text-lg h-12 flex-1"
                    />
                    <Button variant="outline" onClick={handleHoraActualRoturaFin} className="h-12">
                      <Clock className="w-5 h-5" />
                    </Button>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label className="text-base font-medium">Motivo *</Label>
                  <Input
                    value={motivoRotura}
                    onChange={(e) => setMotivoRotura(e.target.value)}
                    placeholder="Ej: Papel seco"
                    className="text-lg h-12"
                  />
                </div>
              </div>

              <Button onClick={handleAnadirRotura} size="lg" className="w-full h-14 text-lg bg-destructive hover:bg-destructive/90">
                <Plus className="w-5 h-5 mr-2" />
                Registrar Rotura
              </Button>

              {roturas.length > 0 && (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Inicio</TableHead>
                      <TableHead>Fin</TableHead>
                      <TableHead>Duración</TableHead>
                      <TableHead>Motivo</TableHead>
                      <TableHead className="w-16"></TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {roturas.map((r) => (
                      <TableRow key={r.id}>
                        <TableCell className="font-medium">{r.horaInicio}</TableCell>
                        <TableCell>{r.horaFin || '-'}</TableCell>
                        <TableCell className="text-destructive font-medium">{r.duracion} min</TableCell>
                        <TableCell>{r.motivo}</TableCell>
                        <TableCell>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => onRoturasChange(roturas.filter(x => x.id !== r.id))}
                            className="text-destructive"
                          >
                            <Trash2 className="w-5 h-5" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="paradas" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl flex items-center gap-3">
                <AlertTriangle className="w-7 h-7" style={{ color: 'hsl(var(--warning))' }} />
                Paradas
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="text-base font-medium">Hora inicio *</Label>
                  <div className="flex gap-2">
                    <Input
                      type="time"
                      value={horaInicioParada}
                      onChange={(e) => setHoraInicioParada(e.target.value)}
                      className="text-lg h-12 flex-1"
                    />
                    <Button variant="outline" onClick={handleHoraActualParadaInicio} className="h-12">
                      <Clock className="w-5 h-5" />
                    </Button>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label className="text-base font-medium">Hora fin</Label>
                  <div className="flex gap-2">
                    <Input
                      type="time"
                      value={horaFinParada}
                      onChange={(e) => setHoraFinParada(e.target.value)}
                      className="text-lg h-12 flex-1"
                    />
                    <Button variant="outline" onClick={handleHoraActualParadaFin} className="h-12">
                      <Clock className="w-5 h-5" />
                    </Button>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label className="text-base font-medium">Tipo *</Label>
                  <Select value={tipoParada} onValueChange={setTipoParada}>
                    <SelectTrigger className="text-lg h-12">
                      <SelectValue placeholder="Seleccione tipo" />
                    </SelectTrigger>
                    <SelectContent>
                      {tiposParada.map((t) => (
                        <SelectItem key={t} value={t} className="text-base py-3">{t}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {tipoParada === 'Otro' && (
                  <div className="space-y-2">
                    <Label className="text-base font-medium">Nuevo tipo de parada</Label>
                    <Input
                      value={nuevoMotivo}
                      onChange={(e) => setNuevoMotivo(e.target.value)}
                      placeholder="Se guardará para futuras ocasiones"
                      className="text-lg h-12"
                    />
                  </div>
                )}

                <div className="space-y-2 md:col-span-2">
                  <Label className="text-base font-medium">Motivo detallado</Label>
                  <Input
                    value={motivoParada}
                    onChange={(e) => setMotivoParada(e.target.value)}
                    placeholder="Descripción detallada de la parada..."
                    className="text-lg h-12"
                  />
                </div>
              </div>

              <Button onClick={handleAnadirParada} size="lg" className="w-full h-14 text-lg" style={{ backgroundColor: 'hsl(var(--warning))' }}>
                <Plus className="w-5 h-5 mr-2" />
                Registrar Parada
              </Button>

              {paradas.length > 0 && (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Inicio</TableHead>
                      <TableHead>Fin</TableHead>
                      <TableHead>Duración</TableHead>
                      <TableHead>Tipo</TableHead>
                      <TableHead>Motivo</TableHead>
                      <TableHead className="w-16"></TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {paradas.map((p) => (
                      <TableRow key={p.id}>
                        <TableCell className="font-medium">{p.horaInicio}</TableCell>
                        <TableCell>{p.horaFin || '-'}</TableCell>
                        <TableCell className="font-medium" style={{ color: 'hsl(var(--warning))' }}>{p.duracion} min</TableCell>
                        <TableCell>{p.tipo}</TableCell>
                        <TableCell>{p.motivoDetallado || '-'}</TableCell>
                        <TableCell>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => onParadasChange(paradas.filter(x => x.id !== p.id))}
                            className="text-destructive"
                          >
                            <Trash2 className="w-5 h-5" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
