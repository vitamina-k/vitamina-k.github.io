import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Textarea } from '@/components/ui/textarea';
import { CambioPapel } from '@/types/factory';
import { FileText, Plus, Clock, Trash2, ArrowRight } from 'lucide-react';
import { toast } from 'sonner';

interface CambiosPapelProps {
  cambios: CambioPapel[];
  onCambiosChange: (cambios: CambioPapel[]) => void;
}

export function CambiosPapel({ cambios, onCambiosChange }: CambiosPapelProps) {
  const [fechaHora, setFechaHora] = useState('');
  const [productoAnterior, setProductoAnterior] = useState('');
  const [productoNuevo, setProductoNuevo] = useState('');
  const [velocidadAntes, setVelocidadAntes] = useState('');
  const [velocidadDespues, setVelocidadDespues] = useState('');
  const [tensionAntes, setTensionAntes] = useState('');
  const [tensionDespues, setTensionDespues] = useState('');
  const [crepado, setCrepado] = useState('');
  const [observaciones, setObservaciones] = useState('');

  const handleHoraActual = () => {
    const now = new Date();
    setFechaHora(now.toISOString().slice(0, 16));
  };

  const handleAnadir = () => {
    if (!productoAnterior || !productoNuevo) {
      toast.error('Indique al menos los productos');
      return;
    }

    const nuevoCambio: CambioPapel = {
      id: Date.now().toString(),
      fechaHora,
      productoAnterior,
      productoNuevo,
      velocidadAntes: parseFloat(velocidadAntes) || 0,
      velocidadDespues: parseFloat(velocidadDespues) || 0,
      tensionAntes: parseFloat(tensionAntes) || 0,
      tensionDespues: parseFloat(tensionDespues) || 0,
      crepado,
      observaciones,
    };

    onCambiosChange([...cambios, nuevoCambio]);
    
    // Reset form
    setFechaHora('');
    setProductoAnterior('');
    setProductoNuevo('');
    setVelocidadAntes('');
    setVelocidadDespues('');
    setTensionAntes('');
    setTensionDespues('');
    setCrepado('');
    setObservaciones('');
    
    toast.success('Cambio de papel registrado');
  };

  const handleEliminar = (id: string) => {
    onCambiosChange(cambios.filter(c => c.id !== id));
    toast.info('Cambio eliminado');
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl flex items-center gap-3">
            <FileText className="w-7 h-7 text-primary" />
            Cambios de Papel (Parámetros Técnicos)
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="text-base font-medium">Fecha/Hora</Label>
              <div className="flex gap-2">
                <Input
                  type="datetime-local"
                  value={fechaHora}
                  onChange={(e) => setFechaHora(e.target.value)}
                  className="text-lg h-12 flex-1"
                />
                <Button variant="outline" onClick={handleHoraActual} className="h-12">
                  <Clock className="w-5 h-5" />
                </Button>
              </div>
            </div>

            <div className="space-y-2">
              <Label className="text-base font-medium">Crepado</Label>
              <Input
                value={crepado}
                onChange={(e) => setCrepado(e.target.value)}
                placeholder="Ej: P16"
                className="text-lg h-12"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card className="bg-secondary/50">
              <CardContent className="p-4 space-y-4">
                <h3 className="font-semibold text-lg flex items-center gap-2">
                  Producto Anterior
                </h3>
                <div className="space-y-2">
                  <Label className="text-sm">Código *</Label>
                  <Input
                    value={productoAnterior}
                    onChange={(e) => setProductoAnterior(e.target.value)}
                    placeholder="Ej: WS 19 P16"
                    className="h-11"
                  />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div className="space-y-2">
                    <Label className="text-sm">Velocidad</Label>
                    <Input
                      type="number"
                      value={velocidadAntes}
                      onChange={(e) => setVelocidadAntes(e.target.value)}
                      placeholder="m/min"
                      className="h-11"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-sm">Tensión</Label>
                    <Input
                      type="number"
                      value={tensionAntes}
                      onChange={(e) => setTensionAntes(e.target.value)}
                      placeholder="N/m"
                      className="h-11"
                    />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-primary/10">
              <CardContent className="p-4 space-y-4">
                <h3 className="font-semibold text-lg flex items-center gap-2">
                  <ArrowRight className="w-5 h-5" />
                  Producto Nuevo
                </h3>
                <div className="space-y-2">
                  <Label className="text-sm">Código *</Label>
                  <Input
                    value={productoNuevo}
                    onChange={(e) => setProductoNuevo(e.target.value)}
                    placeholder="Ej: NP190 P14"
                    className="h-11"
                  />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div className="space-y-2">
                    <Label className="text-sm">Velocidad</Label>
                    <Input
                      type="number"
                      value={velocidadDespues}
                      onChange={(e) => setVelocidadDespues(e.target.value)}
                      placeholder="m/min"
                      className="h-11"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-sm">Tensión</Label>
                    <Input
                      type="number"
                      value={tensionDespues}
                      onChange={(e) => setTensionDespues(e.target.value)}
                      placeholder="N/m"
                      className="h-11"
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="space-y-2">
            <Label className="text-base font-medium">Observaciones</Label>
            <Textarea
              value={observaciones}
              onChange={(e) => setObservaciones(e.target.value)}
              placeholder="Notas sobre el cambio, ajustes realizados..."
              className="min-h-[80px] text-base"
            />
          </div>

          <Button onClick={handleAnadir} size="lg" className="w-full h-14 text-lg font-semibold">
            <Plus className="w-5 h-5 mr-2" />
            Registrar Cambio de Papel
          </Button>
        </CardContent>
      </Card>

      {cambios.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-xl">Cambios Registrados</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Fecha/Hora</TableHead>
                    <TableHead>Anterior → Nuevo</TableHead>
                    <TableHead>Velocidad</TableHead>
                    <TableHead>Tensión</TableHead>
                    <TableHead>Crepado</TableHead>
                    <TableHead>Observaciones</TableHead>
                    <TableHead className="w-16"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {cambios.map((cambio) => (
                    <TableRow key={cambio.id}>
                      <TableCell>
                        {cambio.fechaHora ? new Date(cambio.fechaHora).toLocaleString('es-ES') : '-'}
                      </TableCell>
                      <TableCell>
                        <span className="font-mono">{cambio.productoAnterior}</span>
                        <ArrowRight className="inline w-4 h-4 mx-2 text-muted-foreground" />
                        <span className="font-mono font-medium">{cambio.productoNuevo}</span>
                      </TableCell>
                      <TableCell>
                        {cambio.velocidadAntes || '-'} → {cambio.velocidadDespues || '-'}
                      </TableCell>
                      <TableCell>
                        {cambio.tensionAntes || '-'} → {cambio.tensionDespues || '-'}
                      </TableCell>
                      <TableCell>{cambio.crepado || '-'}</TableCell>
                      <TableCell className="max-w-xs truncate">{cambio.observaciones || '-'}</TableCell>
                      <TableCell>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleEliminar(cambio.id)}
                          className="text-destructive hover:text-destructive"
                        >
                          <Trash2 className="w-5 h-5" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
