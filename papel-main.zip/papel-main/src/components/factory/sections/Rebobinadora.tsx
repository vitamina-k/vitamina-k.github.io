import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { CorteRebobinadora } from '@/types/factory';
import { RotateCcw, Plus, Clock, Trash2 } from 'lucide-react';
import { toast } from 'sonner';

interface RebobinadoraProps {
  cortes: CorteRebobinadora[];
  onCortesChange: (cortes: CorteRebobinadora[]) => void;
}

export function Rebobinadora({ cortes, onCortesChange }: RebobinadoraProps) {
  const [fechaHora, setFechaHora] = useState('');
  const [bobina, setBobina] = useState('');
  const [pesoInicial, setPesoInicial] = useState('');
  const [pesoFinal, setPesoFinal] = useState('');
  const [anchoCorte, setAnchoCorte] = useState('');
  const [observaciones, setObservaciones] = useState('');

  const handleHoraActual = () => {
    const now = new Date();
    setFechaHora(now.toISOString().slice(0, 16));
  };

  const handleAnadir = () => {
    if (!bobina) {
      toast.error('Indique al menos la bobina');
      return;
    }

    const nuevoCorte: CorteRebobinadora = {
      id: Date.now().toString(),
      fechaHora,
      bobina,
      pesoInicial: parseFloat(pesoInicial) || 0,
      pesoFinal: parseFloat(pesoFinal) || 0,
      anchoCorte: parseFloat(anchoCorte) || 0,
      observaciones,
    };

    onCortesChange([...cortes, nuevoCorte]);
    setFechaHora('');
    setBobina('');
    setPesoInicial('');
    setPesoFinal('');
    setAnchoCorte('');
    setObservaciones('');
    toast.success('Corte registrado');
  };

  const handleEliminar = (id: string) => {
    onCortesChange(cortes.filter(c => c.id !== id));
    toast.info('Corte eliminado');
  };

  // Cálculos
  const totalPesoInicial = cortes.reduce((sum, c) => sum + c.pesoInicial, 0);
  const totalPesoFinal = cortes.reduce((sum, c) => sum + c.pesoFinal, 0);
  const totalMerma = totalPesoInicial - totalPesoFinal;

  return (
    <div className="space-y-6">
      {cortes.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card className="bg-primary/10">
            <CardContent className="p-4 text-center">
              <p className="text-sm text-muted-foreground">Total Peso Inicial</p>
              <p className="text-2xl font-bold text-primary">{totalPesoInicial.toFixed(0)} kg</p>
            </CardContent>
          </Card>
          <Card className="bg-accent/10">
            <CardContent className="p-4 text-center">
              <p className="text-sm text-muted-foreground">Total Peso Final</p>
              <p className="text-2xl font-bold text-accent">{totalPesoFinal.toFixed(0)} kg</p>
            </CardContent>
          </Card>
          <Card className="bg-destructive/10">
            <CardContent className="p-4 text-center">
              <p className="text-sm text-muted-foreground">Total Merma</p>
              <p className="text-2xl font-bold text-destructive">{totalMerma.toFixed(0)} kg</p>
            </CardContent>
          </Card>
        </div>
      )}

      <Card>
        <CardHeader>
          <CardTitle className="text-2xl flex items-center gap-3">
            <RotateCcw className="w-7 h-7 text-primary" />
            Rebobinadora y Cortes
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label className="text-base font-medium">Fecha/Hora</Label>
              <div className="flex gap-2">
                <Input
                  type="datetime-local"
                  value={fechaHora}
                  onChange={(e) => setFechaHora(e.target.value)}
                  className="text-lg h-12 flex-1"
                />
                <Button variant="outline" onClick={handleHoraActual} className="h-12">
                  <Clock className="w-5 h-5" />
                </Button>
              </div>
            </div>

            <div className="space-y-2">
              <Label className="text-base font-medium">Bobina *</Label>
              <Input
                value={bobina}
                onChange={(e) => setBobina(e.target.value)}
                placeholder="Ej: B-001"
                className="text-lg h-12"
              />
            </div>

            <div className="space-y-2">
              <Label className="text-base font-medium">Peso Inicial (kg)</Label>
              <Input
                type="number"
                step="0.1"
                value={pesoInicial}
                onChange={(e) => setPesoInicial(e.target.value)}
                placeholder="Ej: 1500"
                className="text-lg h-12"
              />
            </div>

            <div className="space-y-2">
              <Label className="text-base font-medium">Peso Final (kg)</Label>
              <Input
                type="number"
                step="0.1"
                value={pesoFinal}
                onChange={(e) => setPesoFinal(e.target.value)}
                placeholder="Ej: 1480"
                className="text-lg h-12"
              />
            </div>

            <div className="space-y-2">
              <Label className="text-base font-medium">Ancho de Corte (mm)</Label>
              <Input
                type="number"
                value={anchoCorte}
                onChange={(e) => setAnchoCorte(e.target.value)}
                placeholder="Ej: 220"
                className="text-lg h-12"
              />
            </div>

            <div className="space-y-2">
              <Label className="text-base font-medium">Observaciones</Label>
              <Input
                value={observaciones}
                onChange={(e) => setObservaciones(e.target.value)}
                placeholder="Notas adicionales..."
                className="text-lg h-12"
              />
            </div>
          </div>

          <Button onClick={handleAnadir} size="lg" className="w-full h-14 text-lg font-semibold">
            <Plus className="w-5 h-5 mr-2" />
            Registrar Corte
          </Button>
        </CardContent>
      </Card>

      {cortes.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-xl">Cortes Registrados</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Fecha/Hora</TableHead>
                    <TableHead>Bobina</TableHead>
                    <TableHead>Peso Inicial</TableHead>
                    <TableHead>Peso Final</TableHead>
                    <TableHead>Merma</TableHead>
                    <TableHead>Ancho</TableHead>
                    <TableHead>Observaciones</TableHead>
                    <TableHead className="w-16"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {cortes.map((corte) => (
                    <TableRow key={corte.id}>
                      <TableCell>
                        {corte.fechaHora ? new Date(corte.fechaHora).toLocaleString('es-ES') : '-'}
                      </TableCell>
                      <TableCell className="font-medium">{corte.bobina}</TableCell>
                      <TableCell>{corte.pesoInicial ? `${corte.pesoInicial} kg` : '-'}</TableCell>
                      <TableCell>{corte.pesoFinal ? `${corte.pesoFinal} kg` : '-'}</TableCell>
                      <TableCell className="text-destructive font-medium">
                        {corte.pesoInicial && corte.pesoFinal 
                          ? `${(corte.pesoInicial - corte.pesoFinal).toFixed(1)} kg` 
                          : '-'}
                      </TableCell>
                      <TableCell>{corte.anchoCorte ? `${corte.anchoCorte} mm` : '-'}</TableCell>
                      <TableCell className="max-w-xs truncate">{corte.observaciones || '-'}</TableCell>
                      <TableCell>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleEliminar(corte.id)}
                          className="text-destructive hover:text-destructive"
                        >
                          <Trash2 className="w-5 h-5" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
