import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { TurnoInfo } from '@/types/factory';
import { Play, StopCircle, Sun, Sunset, Moon, User } from 'lucide-react';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

interface InicioTurnoProps {
  turnoInfo: TurnoInfo | null;
  onTurnoChange: (turno: TurnoInfo) => void;
}

const turnos = [
  { id: 'Mañana', label: 'Mañana', icon: Sun, color: 'bg-amber-500/20 text-amber-600 border-amber-500/50 hover:bg-amber-500/30' },
  { id: 'Tarde', label: 'Tarde', icon: Sunset, color: 'bg-orange-500/20 text-orange-600 border-orange-500/50 hover:bg-orange-500/30' },
  { id: 'Noche', label: 'Noche', icon: Moon, color: 'bg-indigo-500/20 text-indigo-600 border-indigo-500/50 hover:bg-indigo-500/30' },
];

const maquinistas = ['Kevin Pérez', 'Juan Benito', 'Mijaíl', 'Miguel', 'Ismael Felipe'];
const maquinas = ['PM2', 'PM4'];

export function InicioTurno({ turnoInfo, onTurnoChange }: InicioTurnoProps) {
  const [fecha, setFecha] = useState(new Date().toISOString().split('T')[0]);
  const [turno, setTurno] = useState('');
  const [maquinista, setMaquinista] = useState('');
  const [maquinistaOtro, setMaquinistaOtro] = useState('');
  const [ayudante, setAyudante] = useState('');
  const [maquina, setMaquina] = useState('');

  useEffect(() => {
    if (turnoInfo) {
      setFecha(turnoInfo.fecha);
      setTurno(turnoInfo.turno);
      if (maquinistas.includes(turnoInfo.maquinista)) {
        setMaquinista(turnoInfo.maquinista);
      } else {
        setMaquinista('Otro');
        setMaquinistaOtro(turnoInfo.maquinista);
      }
      setAyudante(turnoInfo.ayudante);
      setMaquina(turnoInfo.maquina);
    }
  }, [turnoInfo]);

  const handleIniciarTurno = () => {
    const nombreMaquinista = maquinista === 'Otro' ? maquinistaOtro : maquinista;
    
    if (!turno || !nombreMaquinista || !maquina) {
      toast.error('Por favor, complete todos los campos obligatorios');
      return;
    }

    onTurnoChange({
      fecha,
      turno,
      maquinista: nombreMaquinista,
      ayudante,
      maquina,
      activo: true,
    });

    toast.success('Turno iniciado correctamente');
  };

  const handleFinalizarTurno = () => {
    if (turnoInfo) {
      onTurnoChange({
        ...turnoInfo,
        activo: false,
      });
      toast.info('Turno finalizado');
    }
  };

  return (
    <Card className="max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="text-2xl flex items-center gap-3">
          <Play className="w-7 h-7 text-primary" />
          Inicio de Turno
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid gap-6">
          <div className="space-y-2">
            <Label htmlFor="fecha" className="text-base font-medium">Fecha</Label>
            <Input
              id="fecha"
              type="date"
              value={fecha}
              onChange={(e) => setFecha(e.target.value)}
              className="text-lg h-12"
            />
          </div>

          {/* Turno - Botones visuales */}
          <div className="space-y-3">
            <Label className="text-base font-medium">Turno *</Label>
            <div className="grid grid-cols-3 gap-3">
              {turnos.map((t) => {
                const Icon = t.icon;
                const isSelected = turno === t.id;
                return (
                  <Button
                    key={t.id}
                    type="button"
                    variant="outline"
                    className={cn(
                      "h-20 flex flex-col gap-2 transition-all border-2",
                      isSelected 
                        ? `${t.color} border-2 ring-2 ring-offset-2 ring-primary/50` 
                        : "hover:bg-muted"
                    )}
                    onClick={() => setTurno(t.id)}
                  >
                    <Icon className="w-8 h-8" />
                    <span className="font-semibold">{t.label}</span>
                  </Button>
                );
              })}
            </div>
          </div>

          {/* Maquinista - Botones visuales */}
          <div className="space-y-3">
            <Label className="text-base font-medium">Maquinista *</Label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {maquinistas.map((m) => {
                const isSelected = maquinista === m;
                return (
                  <Button
                    key={m}
                    type="button"
                    variant="outline"
                    className={cn(
                      "h-14 flex items-center gap-2 transition-all border-2",
                      isSelected 
                        ? "bg-primary/10 text-primary border-primary ring-2 ring-offset-2 ring-primary/50" 
                        : "hover:bg-muted"
                    )}
                    onClick={() => {
                      setMaquinista(m);
                      setMaquinistaOtro('');
                    }}
                  >
                    <User className="w-5 h-5 flex-shrink-0" />
                    <span className="font-medium text-sm truncate">{m}</span>
                  </Button>
                );
              })}
              <Button
                type="button"
                variant="outline"
                className={cn(
                  "h-14 flex items-center gap-2 transition-all border-2",
                  maquinista === 'Otro' 
                    ? "bg-primary/10 text-primary border-primary ring-2 ring-offset-2 ring-primary/50" 
                    : "hover:bg-muted"
                )}
                onClick={() => setMaquinista('Otro')}
              >
                <User className="w-5 h-5" />
                <span className="font-medium">Otro...</span>
              </Button>
            </div>
            {maquinista === 'Otro' && (
              <Input
                placeholder="Escriba el nombre del maquinista"
                value={maquinistaOtro}
                onChange={(e) => setMaquinistaOtro(e.target.value)}
                className="text-lg h-12 mt-2"
              />
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="ayudante" className="text-base font-medium">Ayudante</Label>
            <Input
              id="ayudante"
              value={ayudante}
              onChange={(e) => setAyudante(e.target.value)}
              placeholder="Nombre del ayudante"
              className="text-lg h-12"
            />
          </div>

          {/* Máquina - Botones grandes */}
          <div className="space-y-3">
            <Label className="text-base font-medium">Máquina / Línea *</Label>
            <div className="grid grid-cols-2 gap-4">
              {maquinas.map((m) => {
                const isSelected = maquina === m;
                return (
                  <Button
                    key={m}
                    type="button"
                    variant="outline"
                    className={cn(
                      "h-16 text-xl font-bold transition-all border-2",
                      isSelected 
                        ? "bg-primary text-primary-foreground border-primary" 
                        : "hover:bg-muted"
                    )}
                    onClick={() => setMaquina(m)}
                  >
                    {m}
                  </Button>
                );
              })}
            </div>
          </div>
        </div>

        <div className="flex gap-4 pt-4">
          {!turnoInfo?.activo ? (
            <Button 
              onClick={handleIniciarTurno} 
              size="lg" 
              className="flex-1 h-14 text-lg font-semibold"
            >
              <Play className="w-5 h-5 mr-2" />
              Iniciar Turno
            </Button>
          ) : (
            <Button 
              onClick={handleFinalizarTurno} 
              variant="destructive"
              size="lg" 
              className="flex-1 h-14 text-lg font-semibold"
            >
              <StopCircle className="w-5 h-5 mr-2" />
              Finalizar Turno
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}