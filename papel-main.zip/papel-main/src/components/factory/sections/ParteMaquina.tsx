import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { AccionMaquina } from '@/types/factory';
import { Gauge, Plus, Clock, Trash2, Filter } from 'lucide-react';
import { toast } from 'sonner';

interface ParteMaquinaProps {
  acciones: AccionMaquina[];
  onAccionesChange: (acciones: AccionMaquina[]) => void;
}

const tiposAccion = [
  'Ajuste de parámetros',
  'Parada Máquina',
  'Cambio de receta',
  'Cambio de cuchilla',
  'Cambio de papel',
];

const tiposCuchilla = ['Limpieza', 'Crepado', 'Corte'];
const motivosCuchilla = ['Nº de horas', 'Mejorar resistencias', 'Otras causas'];
const motivosParada = ['Parada programada', 'Corte de luz', 'Pulper lleno', 'Avería', 'Otras causas'];

export function ParteMaquina({ acciones, onAccionesChange }: ParteMaquinaProps) {
  const [hora, setHora] = useState('');
  const [tipoAccion, setTipoAccion] = useState('');
  const [filtroAccion, setFiltroAccion] = useState('todos');
  
  // Campos para Cambio de receta
  const [tipoReceta, setTipoReceta] = useState('');
  const [detalleReceta, setDetalleReceta] = useState('');
  
  // Campos para Cambio de cuchilla
  const [tipoCuchilla, setTipoCuchilla] = useState('');
  const [motivoCuchilla, setMotivoCuchilla] = useState('');
  
  // Campos para Cambio de papel
  const [tipoPapel, setTipoPapel] = useState('');
  const [clientePapel, setClientePapel] = useState('');
  
  // Campos para Ajuste de parámetros
  const [detalleAjuste, setDetalleAjuste] = useState('');
  
  // Campos para Parada Máquina
  const [motivoParada, setMotivoParada] = useState('');
  const [descripcionParada, setDescripcionParada] = useState('');

  const handleHoraActual = () => {
    const now = new Date();
    setHora(now.toTimeString().slice(0, 5));
  };

  const handleAnadir = () => {
    if (!hora || !tipoAccion) {
      toast.error('Complete al menos la hora y el tipo de acción');
      return;
    }

    let comentario = '';
    
    if (tipoAccion === 'Ajuste de parámetros') {
      comentario = detalleAjuste ? `Ajuste: ${detalleAjuste}` : 'Ajuste de parámetros';
    } else if (tipoAccion === 'Parada Máquina') {
      if (!motivoParada) {
        toast.error('Indique el motivo de la parada');
        return;
      }
      comentario = `Motivo: ${motivoParada}${descripcionParada ? ` | Descripción: ${descripcionParada}` : ''}`;
    } else if (tipoAccion === 'Cambio de receta') {
      if (!tipoReceta) {
        toast.error('Indique el tipo de receta');
        return;
      }
      comentario = `Receta: ${tipoReceta}${detalleReceta ? ` - ${detalleReceta}` : ''}`;
    } else if (tipoAccion === 'Cambio de cuchilla') {
      if (!tipoCuchilla || !motivoCuchilla) {
        toast.error('Complete el tipo y motivo del cambio de cuchilla');
        return;
      }
      comentario = `Tipo: ${tipoCuchilla} | Motivo: ${motivoCuchilla}`;
    } else if (tipoAccion === 'Cambio de papel') {
      if (!tipoPapel) {
        toast.error('Indique el tipo de papel');
        return;
      }
      comentario = `Papel: ${tipoPapel}${clientePapel ? ` | Cliente: ${clientePapel}` : ''}`;
    }

    const nuevaAccion: AccionMaquina = {
      id: Date.now().toString(),
      hora,
      tipoAccion,
      velocidad: 0,
      comentario,
    };

    // Añadir al principio de la lista
    onAccionesChange([nuevaAccion, ...acciones]);
    
    // Reset form
    setHora('');
    setTipoAccion('');
    setTipoReceta('');
    setDetalleReceta('');
    setTipoCuchilla('');
    setMotivoCuchilla('');
    setTipoPapel('');
    setClientePapel('');
    setDetalleAjuste('');
    setMotivoParada('');
    setDescripcionParada('');
    
    toast.success('Acción registrada');
  };

  const handleEliminar = (id: string) => {
    onAccionesChange(acciones.filter(a => a.id !== id));
    toast.info('Acción eliminada');
  };

  // Filtrar acciones
  const accionesFiltradas = filtroAccion === 'todos' 
    ? acciones 
    : acciones.filter(a => a.tipoAccion === filtroAccion);

  // Obtener color de badge según tipo
  const getBadgeVariant = (tipo: string) => {
    switch (tipo) {
      case 'Ajuste de parámetros': return 'default';
      case 'Parada Máquina': return 'destructive';
      case 'Cambio de receta': return 'secondary';
      case 'Cambio de cuchilla': return 'outline';
      case 'Cambio de papel': return 'outline';
      default: return 'default';
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl flex items-center gap-3">
            <Gauge className="w-7 h-7 text-primary" />
            Parte de Máquina / Desarrollo del Turno
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="text-base font-medium">Hora *</Label>
              <div className="flex gap-2">
                <Input
                  type="time"
                  value={hora}
                  onChange={(e) => setHora(e.target.value)}
                  className="text-lg h-12 flex-1"
                />
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={handleHoraActual}
                  className="h-12 px-4"
                >
                  <Clock className="w-5 h-5" />
                </Button>
              </div>
            </div>

            <div className="space-y-2">
              <Label className="text-base font-medium">Tipo de acción *</Label>
              <Select value={tipoAccion} onValueChange={(v) => {
                setTipoAccion(v);
                // Reset campos específicos
                setTipoReceta('');
                setDetalleReceta('');
                setTipoCuchilla('');
                setMotivoCuchilla('');
                setTipoPapel('');
                setClientePapel('');
                setDetalleAjuste('');
                setMotivoParada('');
                setDescripcionParada('');
              }}>
                <SelectTrigger className="text-lg h-12">
                  <SelectValue placeholder="Seleccione tipo" />
                </SelectTrigger>
                <SelectContent>
                  {tiposAccion.map((t) => (
                    <SelectItem key={t} value={t} className="text-base py-3">{t}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Campos específicos para Ajuste de parámetros */}
          {tipoAccion === 'Ajuste de parámetros' && (
            <div className="p-4 bg-muted/50 rounded-lg">
              <div className="space-y-2">
                <Label className="text-base font-medium">Descripción del ajuste</Label>
                <Input
                  value={detalleAjuste}
                  onChange={(e) => setDetalleAjuste(e.target.value)}
                  placeholder="Ej: Ajuste de presión, velocidad, etc."
                  className="text-lg h-12"
                />
              </div>
            </div>
          )}

          {/* Campos específicos para Parada Máquina */}
          {tipoAccion === 'Parada Máquina' && (
            <div className="space-y-4 p-4 bg-muted/50 rounded-lg">
              <div className="space-y-2">
                <Label className="text-base font-medium">Motivo de la parada *</Label>
                <Select value={motivoParada} onValueChange={setMotivoParada}>
                  <SelectTrigger className="text-lg h-12">
                    <SelectValue placeholder="Seleccione motivo" />
                  </SelectTrigger>
                  <SelectContent>
                    {motivosParada.map((m) => (
                      <SelectItem key={m} value={m} className="text-base py-3">{m}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label className="text-base font-medium">Descripción de lo ocurrido</Label>
                <Input
                  value={descripcionParada}
                  onChange={(e) => setDescripcionParada(e.target.value)}
                  placeholder="Especifique detalles adicionales si es necesario"
                  className="text-lg h-12"
                />
              </div>
            </div>
          )}

          {/* Campos específicos para Cambio de receta */}
          {tipoAccion === 'Cambio de receta' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 bg-muted/50 rounded-lg">
              <div className="space-y-2">
                <Label className="text-base font-medium">Indica el tipo de receta *</Label>
                <Input
                  value={tipoReceta}
                  onChange={(e) => setTipoReceta(e.target.value)}
                  placeholder="Ej: Receta cocina estándar"
                  className="text-lg h-12"
                />
              </div>
              <div className="space-y-2">
                <Label className="text-base font-medium">Detalle de receta</Label>
                <Input
                  value={detalleReceta}
                  onChange={(e) => setDetalleReceta(e.target.value)}
                  placeholder="Lo que lleva o notas adicionales"
                  className="text-lg h-12"
                />
              </div>
            </div>
          )}

          {/* Campos específicos para Cambio de cuchilla */}
          {tipoAccion === 'Cambio de cuchilla' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 bg-muted/50 rounded-lg">
              <div className="space-y-2">
                <Label className="text-base font-medium">Tipo de cuchilla *</Label>
                <Select value={tipoCuchilla} onValueChange={setTipoCuchilla}>
                  <SelectTrigger className="text-lg h-12">
                    <SelectValue placeholder="Seleccione tipo" />
                  </SelectTrigger>
                  <SelectContent>
                    {tiposCuchilla.map((t) => (
                      <SelectItem key={t} value={t} className="text-base py-3">{t}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label className="text-base font-medium">Motivo del cambio *</Label>
                <Select value={motivoCuchilla} onValueChange={setMotivoCuchilla}>
                  <SelectTrigger className="text-lg h-12">
                    <SelectValue placeholder="Seleccione motivo" />
                  </SelectTrigger>
                  <SelectContent>
                    {motivosCuchilla.map((m) => (
                      <SelectItem key={m} value={m} className="text-base py-3">{m}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          )}

          {/* Campos específicos para Cambio de papel */}
          {tipoAccion === 'Cambio de papel' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 bg-muted/50 rounded-lg">
              <div className="space-y-2">
                <Label className="text-base font-medium">Tipo de papel *</Label>
                <Input
                  value={tipoPapel}
                  onChange={(e) => setTipoPapel(e.target.value)}
                  placeholder="Ej: Tissue 18g"
                  className="text-lg h-12"
                />
              </div>
              <div className="space-y-2">
                <Label className="text-base font-medium">Cliente</Label>
                <Input
                  value={clientePapel}
                  onChange={(e) => setClientePapel(e.target.value)}
                  placeholder="Casa o nombre del cliente"
                  className="text-lg h-12"
                />
              </div>
            </div>
          )}

          <Button 
            onClick={handleAnadir} 
            size="lg" 
            className="w-full h-14 text-lg font-semibold"
          >
            <Plus className="w-5 h-5 mr-2" />
            Añadir Acción
          </Button>
        </CardContent>
      </Card>

      {/* Registro de acciones con filtro */}
      <Card>
        <CardHeader>
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <CardTitle className="text-xl">Registro de Acciones</CardTitle>
            <div className="flex items-center gap-2">
              <Filter className="w-5 h-5 text-muted-foreground" />
              <Select value={filtroAccion} onValueChange={setFiltroAccion}>
                <SelectTrigger className="w-[200px]">
                  <SelectValue placeholder="Filtrar por tipo" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="todos">Todas las acciones</SelectItem>
                  {tiposAccion.map((t) => (
                    <SelectItem key={t} value={t}>{t}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {accionesFiltradas.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              {acciones.length === 0 
                ? 'No hay acciones registradas aún' 
                : 'No hay acciones con el filtro seleccionado'}
            </div>
          ) : (
            <div className="space-y-3">
              {accionesFiltradas.map((accion) => (
                <div 
                  key={accion.id}
                  className="flex items-start gap-4 p-4 bg-muted/30 rounded-lg border border-border/50 hover:bg-muted/50 transition-colors"
                >
                  <div className="text-2xl font-bold text-primary min-w-[60px]">
                    {accion.hora}
                  </div>
                  <div className="flex-1 space-y-2">
                    <Badge variant={getBadgeVariant(accion.tipoAccion)}>
                      {accion.tipoAccion}
                    </Badge>
                    {accion.comentario && (
                      <p className="text-sm text-muted-foreground">{accion.comentario}</p>
                    )}
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => handleEliminar(accion.id)}
                    className="text-destructive hover:text-destructive hover:bg-destructive/10"
                  >
                    <Trash2 className="w-5 h-5" />
                  </Button>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}