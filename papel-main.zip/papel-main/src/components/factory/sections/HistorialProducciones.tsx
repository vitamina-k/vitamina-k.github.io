import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { History, Search, Construction } from 'lucide-react';

export function HistorialProducciones() {
  return (
    <Card className="max-w-4xl mx-auto">
      <CardHeader>
        <CardTitle className="text-2xl flex items-center gap-3">
          <History className="w-7 h-7 text-primary" />
          Historial de Producciones
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col items-center justify-center py-16 text-center space-y-6">
          <div className="w-24 h-24 rounded-full bg-muted flex items-center justify-center">
            <Construction className="w-12 h-12 text-muted-foreground" />
          </div>
          
          <div className="space-y-2">
            <h3 className="text-xl font-semibold text-foreground">Sección en Construcción</h3>
            <p className="text-muted-foreground max-w-md">
              Próximamente podrás buscar fabricaciones anteriores filtrando por:
            </p>
          </div>

          <div className="flex flex-wrap gap-2 justify-center">
            <Badge variant="outline" className="text-sm py-1 px-3">
              <Search className="w-4 h-4 mr-1" />
              Nombre Cliente
            </Badge>
            <Badge variant="outline" className="text-sm py-1 px-3">
              Cocina
            </Badge>
            <Badge variant="outline" className="text-sm py-1 px-3">
              Servilleta
            </Badge>
            <Badge variant="outline" className="text-sm py-1 px-3">
              Higiénico
            </Badge>
            <Badge variant="outline" className="text-sm py-1 px-3">
              Prueba
            </Badge>
          </div>

          <div className="bg-muted/50 rounded-lg p-4 max-w-lg">
            <p className="text-sm text-muted-foreground">
              <strong>Funcionalidades previstas:</strong>
            </p>
            <ul className="text-sm text-muted-foreground mt-2 space-y-1 text-left">
              <li>• Estado de la máquina según parámetros</li>
              <li>• Búsqueda por filtros de fabricación</li>
              <li>• Detalles de configuración anterior</li>
              <li>• Anomalías detectadas y soluciones aplicadas</li>
            </ul>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
