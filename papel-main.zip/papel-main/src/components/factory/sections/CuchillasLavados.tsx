import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { CambioCuchilla, Lavado } from '@/types/factory';
import { Droplets, Plus, Clock, Trash2 } from 'lucide-react';
import { toast } from 'sonner';

interface CuchillasLavadosProps {
  cuchillas: CambioCuchilla[];
  lavados: Lavado[];
  onCuchillasChange: (cuchillas: CambioCuchilla[]) => void;
  onLavadosChange: (lavados: Lavado[]) => void;
}

const tiposLavado = ['Renew', 'Sosa'];

export function CuchillasLavados({ lavados, onLavadosChange }: CuchillasLavadosProps) {
  // Lavados state
  const [fechaHoraLavado, setFechaHoraLavado] = useState('');
  const [tipoLavado, setTipoLavado] = useState('');
  const [parteLavada, setParteLavada] = useState('');
  const [motivoLavado, setMotivoLavado] = useState('');
  const [tiempoLavado, setTiempoLavado] = useState('');

  const handleHoraActualLavado = () => {
    const now = new Date();
    setFechaHoraLavado(now.toISOString().slice(0, 16));
  };

  const handleAnadirLavado = () => {
    if (!fechaHoraLavado || !tipoLavado) {
      toast.error('Complete los campos obligatorios');
      return;
    }

    const nuevoLavado: Lavado = {
      id: Date.now().toString(),
      fechaHora: fechaHoraLavado,
      tipo: tipoLavado,
      parteLavada,
      motivo: motivoLavado,
      tiempo: parseInt(tiempoLavado) || 0,
    };

    onLavadosChange([...lavados, nuevoLavado]);
    setFechaHoraLavado('');
    setTipoLavado('');
    setParteLavada('');
    setMotivoLavado('');
    setTiempoLavado('');
    toast.success('Lavado registrado');
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl flex items-center gap-3">
            <Droplets className="w-7 h-7 text-primary" />
            Lavados
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label className="text-base font-medium">Fecha/Hora *</Label>
              <div className="flex gap-2">
                <Input
                  type="datetime-local"
                  value={fechaHoraLavado}
                  onChange={(e) => setFechaHoraLavado(e.target.value)}
                  className="text-lg h-12 flex-1"
                />
                <Button variant="outline" onClick={handleHoraActualLavado} className="h-12">
                  <Clock className="w-5 h-5" />
                </Button>
              </div>
            </div>

            <div className="space-y-2">
              <Label className="text-base font-medium">Tipo de lavado *</Label>
              <Select value={tipoLavado} onValueChange={setTipoLavado}>
                <SelectTrigger className="text-lg h-12">
                  <SelectValue placeholder="Seleccione tipo" />
                </SelectTrigger>
                <SelectContent>
                  {tiposLavado.map((t) => (
                    <SelectItem key={t} value={t} className="text-base py-3">{t}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label className="text-base font-medium">Parte lavada</Label>
              <Input
                value={parteLavada}
                onChange={(e) => setParteLavada(e.target.value)}
                placeholder="Ej: Cilindro secador"
                className="text-lg h-12"
              />
            </div>

            <div className="space-y-2">
              <Label className="text-base font-medium">Motivo</Label>
              <Input
                value={motivoLavado}
                onChange={(e) => setMotivoLavado(e.target.value)}
                placeholder="Ej: Mantenimiento programado"
                className="text-lg h-12"
              />
            </div>

            <div className="space-y-2">
              <Label className="text-base font-medium">Tiempo (minutos)</Label>
              <Input
                type="number"
                value={tiempoLavado}
                onChange={(e) => setTiempoLavado(e.target.value)}
                placeholder="Ej: 30"
                className="text-lg h-12"
              />
            </div>
          </div>

          <Button onClick={handleAnadirLavado} size="lg" className="w-full h-14 text-lg">
            <Plus className="w-5 h-5 mr-2" />
            Registrar Lavado
          </Button>

          {lavados.length > 0 && (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Fecha/Hora</TableHead>
                  <TableHead>Tipo</TableHead>
                  <TableHead>Parte</TableHead>
                  <TableHead>Motivo</TableHead>
                  <TableHead>Tiempo</TableHead>
                  <TableHead className="w-16"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {lavados.map((l) => (
                  <TableRow key={l.id}>
                    <TableCell>{new Date(l.fechaHora).toLocaleString('es-ES')}</TableCell>
                    <TableCell className="font-medium">{l.tipo}</TableCell>
                    <TableCell>{l.parteLavada || '-'}</TableCell>
                    <TableCell>{l.motivo || '-'}</TableCell>
                    <TableCell>{l.tiempo ? `${l.tiempo} min` : '-'}</TableCell>
                    <TableCell>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => onLavadosChange(lavados.filter(x => x.id !== l.id))}
                        className="text-destructive"
                      >
                        <Trash2 className="w-5 h-5" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
