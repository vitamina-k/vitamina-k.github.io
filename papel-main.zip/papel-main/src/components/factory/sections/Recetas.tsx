import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Textarea } from '@/components/ui/textarea';
import { Receta } from '@/types/factory';
import { BookOpen, Plus, Trash2, AlertCircle } from 'lucide-react';
import { toast } from 'sonner';

interface RecetasProps {
  recetas: Receta[];
  onRecetasChange: (recetas: Receta[]) => void;
}

export function Recetas({ recetas, onRecetasChange }: RecetasProps) {
  const [nombre, setNombre] = useState('');
  const [producto, setProducto] = useState('');
  const [comentario, setComentario] = useState('');
  const [noRepetir, setNoRepetir] = useState(false);

  const handleAnadir = () => {
    if (!nombre || !producto) {
      toast.error('Complete al menos el nombre y producto');
      return;
    }

    const nuevaReceta: Receta = {
      id: Date.now().toString(),
      nombre,
      producto,
      comentario,
      noRepetir,
    };

    onRecetasChange([...recetas, nuevaReceta]);
    setNombre('');
    setProducto('');
    setComentario('');
    setNoRepetir(false);
    toast.success('Receta registrada');
  };

  const handleEliminar = (id: string) => {
    onRecetasChange(recetas.filter(r => r.id !== id));
    toast.info('Receta eliminada');
  };

  const handleToggleNoRepetir = (id: string) => {
    onRecetasChange(recetas.map(r => 
      r.id === id ? { ...r, noRepetir: !r.noRepetir } : r
    ));
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl flex items-center gap-3">
            <BookOpen className="w-7 h-7 text-primary" />
            Registro de Recetas
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="text-base font-medium">Nombre de receta *</Label>
              <Input
                value={nombre}
                onChange={(e) => setNombre(e.target.value)}
                placeholder="Ej: Receta cocina estándar"
                className="text-lg h-12"
              />
            </div>

            <div className="space-y-2">
              <Label className="text-base font-medium">Producto al que se aplica *</Label>
              <Input
                value={producto}
                onChange={(e) => setProducto(e.target.value)}
                placeholder="Ej: WS 19 P16 274C12"
                className="text-lg h-12"
              />
            </div>

            <div className="space-y-2 md:col-span-2">
              <Label className="text-base font-medium">Comentario</Label>
              <Textarea
                value={comentario}
                onChange={(e) => setComentario(e.target.value)}
                placeholder="¿Funcionó bien? ¿Qué se puede mejorar?"
                className="min-h-[100px] text-base"
              />
            </div>

            <div className="flex items-center space-x-3 md:col-span-2">
              <Checkbox
                id="noRepetir"
                checked={noRepetir}
                onCheckedChange={(checked) => setNoRepetir(checked as boolean)}
                className="w-6 h-6"
              />
              <Label htmlFor="noRepetir" className="text-base font-medium cursor-pointer flex items-center gap-2">
                <AlertCircle className="w-5 h-5 text-destructive" />
                No repetir esta receta con este producto
              </Label>
            </div>
          </div>

          <Button onClick={handleAnadir} size="lg" className="w-full h-14 text-lg font-semibold">
            <Plus className="w-5 h-5 mr-2" />
            Registrar Receta
          </Button>
        </CardContent>
      </Card>

      {recetas.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-xl">Recetas Registradas</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Nombre</TableHead>
                    <TableHead>Producto</TableHead>
                    <TableHead>Comentario</TableHead>
                    <TableHead className="text-center">No Repetir</TableHead>
                    <TableHead className="w-16"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {recetas.map((receta) => (
                    <TableRow key={receta.id} className={receta.noRepetir ? 'bg-destructive/5' : ''}>
                      <TableCell className="font-medium">{receta.nombre}</TableCell>
                      <TableCell className="font-mono">{receta.producto}</TableCell>
                      <TableCell className="max-w-xs truncate">{receta.comentario || '-'}</TableCell>
                      <TableCell className="text-center">
                        <Checkbox
                          checked={receta.noRepetir}
                          onCheckedChange={() => handleToggleNoRepetir(receta.id)}
                          className="w-5 h-5"
                        />
                      </TableCell>
                      <TableCell>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleEliminar(receta.id)}
                          className="text-destructive hover:text-destructive"
                        >
                          <Trash2 className="w-5 h-5" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
