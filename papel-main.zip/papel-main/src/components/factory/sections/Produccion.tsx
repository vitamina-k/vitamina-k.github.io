import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Bobina, KilosCortados } from '@/types/factory';
import { Scale, Plus, Trash2 } from 'lucide-react';
import { toast } from 'sonner';

interface ProduccionProps {
  bobinas: Bobina[];
  kilosCortados: KilosCortados[];
  onBobinasChange: (bobinas: Bobina[]) => void;
  onKilosCortadosChange: (kilos: KilosCortados[]) => void;
}

const tiposBobina = ['A', 'B', 'Cortada'] as const;
const motivosCorte = ['Arranque de máquina', 'Motas', 'Cigarros', 'Desplazada'];

export function Produccion({ bobinas, kilosCortados, onBobinasChange, onKilosCortadosChange }: ProduccionProps) {
  const [numeroBobina, setNumeroBobina] = useState('');
  const [pesoBobina, setPesoBobina] = useState('');
  const [tipoBobina, setTipoBobina] = useState<string>('A');
  
  const [motivoCorte, setMotivoCorte] = useState('');
  const [kilosCorte, setKilosCorte] = useState('');

  const handleAnadirBobina = () => {
    if (!numeroBobina || !pesoBobina) {
      toast.error('Complete el número y peso de la bobina');
      return;
    }

    // Map the new types to the existing Bobina type
    const tipoMapeado = tipoBobina === 'A' ? 'Buena' : tipoBobina === 'B' ? 'B' : 'Cortada/Desecho';

    const nuevaBobina: Bobina = {
      id: Date.now().toString(),
      numero: parseInt(numeroBobina),
      peso: parseFloat(pesoBobina),
      tipo: tipoMapeado as Bobina['tipo'],
    };

    onBobinasChange([...bobinas, nuevaBobina]);
    setNumeroBobina('');
    setPesoBobina('');
    setTipoBobina('A');
    toast.success('Bobina registrada');
  };

  const handleAnadirKilosCortados = () => {
    if (!motivoCorte || !kilosCorte) {
      toast.error('Complete el motivo y los kilos cortados');
      return;
    }

    const nuevosKilos: KilosCortados = {
      id: Date.now().toString(),
      motivo: motivoCorte,
      kilos: parseFloat(kilosCorte),
    };

    onKilosCortadosChange([...kilosCortados, nuevosKilos]);
    setMotivoCorte('');
    setKilosCorte('');
    toast.success('Kilos cortados registrados');
  };

  const handleEliminarBobina = (id: string) => {
    onBobinasChange(bobinas.filter(b => b.id !== id));
  };

  const handleEliminarKilos = (id: string) => {
    onKilosCortadosChange(kilosCortados.filter(k => k.id !== id));
  };

  // Calculations
  const totalA = bobinas.filter(b => b.tipo === 'Buena').reduce((sum, b) => sum + b.peso, 0);
  const totalB = bobinas.filter(b => b.tipo === 'B').reduce((sum, b) => sum + b.peso, 0);
  const totalCortada = bobinas.filter(b => b.tipo === 'Cortada/Desecho').reduce((sum, b) => sum + b.peso, 0);
  const totalKilosCortados = kilosCortados.reduce((sum, k) => sum + k.kilos, 0);
  const totalProduccion = totalA + totalB + totalCortada;
  const porcentajeMerma = totalProduccion > 0 
    ? ((totalCortada + totalKilosCortados) / (totalProduccion + totalKilosCortados) * 100).toFixed(2) 
    : '0.00';

  // Helper to display type label
  const getTipoLabel = (tipo: Bobina['tipo']) => {
    if (tipo === 'Buena') return 'A';
    if (tipo === 'B') return 'B';
    return 'Cortada';
  };

  return (
    <div className="space-y-6">
      {/* Resumen */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="bg-accent/10">
          <CardContent className="p-4 text-center">
            <p className="text-sm text-muted-foreground">Kilos A</p>
            <p className="text-2xl font-bold text-accent">{totalA.toFixed(0)} kg</p>
          </CardContent>
        </Card>
        <Card className="bg-warning/10">
          <CardContent className="p-4 text-center">
            <p className="text-sm text-muted-foreground">Kilos B</p>
            <p className="text-2xl font-bold" style={{ color: 'hsl(var(--warning))' }}>{totalB.toFixed(0)} kg</p>
          </CardContent>
        </Card>
        <Card className="bg-destructive/10">
          <CardContent className="p-4 text-center">
            <p className="text-sm text-muted-foreground">Kilos Cortados</p>
            <p className="text-2xl font-bold text-destructive">{(totalCortada + totalKilosCortados).toFixed(0)} kg</p>
          </CardContent>
        </Card>
        <Card className="bg-primary/10">
          <CardContent className="p-4 text-center">
            <p className="text-sm text-muted-foreground">% Merma</p>
            <p className="text-2xl font-bold text-primary">{porcentajeMerma}%</p>
          </CardContent>
        </Card>
      </div>

      {/* Bobinas */}
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl flex items-center gap-3">
            <Scale className="w-7 h-7 text-primary" />
            Peso de Bobinas
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label className="text-base font-medium">Nº de Bobina</Label>
              <Input
                type="number"
                value={numeroBobina}
                onChange={(e) => setNumeroBobina(e.target.value)}
                placeholder="Ej: 1"
                className="text-lg h-12"
              />
            </div>

            <div className="space-y-2">
              <Label className="text-base font-medium">Peso (kg)</Label>
              <Input
                type="number"
                step="0.1"
                value={pesoBobina}
                onChange={(e) => setPesoBobina(e.target.value)}
                placeholder="Ej: 1500"
                className="text-lg h-12"
              />
            </div>

            <div className="space-y-2">
              <Label className="text-base font-medium">Tipo</Label>
              <Select value={tipoBobina} onValueChange={setTipoBobina}>
                <SelectTrigger className="text-lg h-12">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {tiposBobina.map((t) => (
                    <SelectItem key={t} value={t} className="text-base py-3">{t}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <Button 
            onClick={handleAnadirBobina} 
            size="lg" 
            className="w-full h-12 text-lg"
          >
            <Plus className="w-5 h-5 mr-2" />
            Añadir Bobina
          </Button>

          {bobinas.length > 0 && (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Nº</TableHead>
                  <TableHead>Peso (kg)</TableHead>
                  <TableHead>Tipo</TableHead>
                  <TableHead className="w-16"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {bobinas.map((bobina) => (
                  <TableRow key={bobina.id}>
                    <TableCell className="font-medium">{bobina.numero}</TableCell>
                    <TableCell>{bobina.peso} kg</TableCell>
                    <TableCell>
                      <span className={
                        bobina.tipo === 'Buena' ? 'text-accent font-medium' :
                        bobina.tipo === 'B' ? 'font-medium' : 'text-destructive font-medium'
                      }>
                        {getTipoLabel(bobina.tipo)}
                      </span>
                    </TableCell>
                    <TableCell>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleEliminarBobina(bobina.id)}
                        className="text-destructive"
                      >
                        <Trash2 className="w-5 h-5" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Kilos Cortados */}
      <Card>
        <CardHeader>
          <CardTitle className="text-xl">Kilos Cortados</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="text-base font-medium">Motivo</Label>
              <Select value={motivoCorte} onValueChange={setMotivoCorte}>
                <SelectTrigger className="text-lg h-12">
                  <SelectValue placeholder="Seleccione motivo" />
                </SelectTrigger>
                <SelectContent>
                  {motivosCorte.map((m) => (
                    <SelectItem key={m} value={m} className="text-base py-3">{m}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label className="text-base font-medium">Kilos</Label>
              <Input
                type="number"
                step="0.1"
                value={kilosCorte}
                onChange={(e) => setKilosCorte(e.target.value)}
                placeholder="Ej: 50"
                className="text-lg h-12"
              />
            </div>
          </div>

          <Button 
            onClick={handleAnadirKilosCortados} 
            variant="secondary"
            size="lg" 
            className="w-full h-12 text-lg"
          >
            <Plus className="w-5 h-5 mr-2" />
            Añadir Kilos Cortados
          </Button>

          {kilosCortados.length > 0 && (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Motivo</TableHead>
                  <TableHead>Kilos</TableHead>
                  <TableHead className="w-16"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {kilosCortados.map((corte) => (
                  <TableRow key={corte.id}>
                    <TableCell>{corte.motivo}</TableCell>
                    <TableCell className="text-destructive font-medium">{corte.kilos} kg</TableCell>
                    <TableCell>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleEliminarKilos(corte.id)}
                        className="text-destructive"
                      >
                        <Trash2 className="w-5 h-5" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
